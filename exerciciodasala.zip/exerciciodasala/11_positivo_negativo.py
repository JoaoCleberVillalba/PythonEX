numero = float(input("Digite um número: "))
if numero >
