usuario = input("Digite o usuário: ")
senha = input("Digite a senha: ")
if usuario == "admin" and senha == "1234":
    print("Login bem-sucedido")
else:
    print("Login falhou")
