nome = input("Digite o nome: ")
idade = int(input("Digite a idade: "))
print(f"Nome: {nome}, Idade: {idade}")
