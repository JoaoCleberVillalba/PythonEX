nome = input("Digite o nome: ")
idade = int(input("Digite a idade: "))
salario = float(input("Digite o salário: "))
if idade >= 18 and salario > 2000:
    print(f"{nome} pode financiar o carro")
else:
    print(f"{nome} não pode financiar o carro")
