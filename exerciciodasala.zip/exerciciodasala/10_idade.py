ano_nascimento = int(input("Digite o ano de nascimento: "))
ano_atual = 2024  # Assumindo ano atual
idade = ano_atual - ano_nascimento
print(f"Sua idade é: {idade} anos")
