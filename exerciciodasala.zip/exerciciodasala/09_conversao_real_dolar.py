reais = float(input("Digite o valor em reais: "))
taxa = 5.0
dolares = reais / taxa
print(f"{reais} reais equivalem a {dolares:.2f} dólares")
