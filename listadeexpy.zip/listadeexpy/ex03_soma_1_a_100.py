# Exercício 3: Calcule a soma de 1 a 100

soma = 0
for i in range(1, 101):
    soma += i

print(f"A soma dos números de 1 a 100 é: {soma}")

