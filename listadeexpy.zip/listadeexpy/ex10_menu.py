# Exercício 10: Menu simples com opções até sair

while True:
    print("\n--- MENU ---")
    print("1 - Dizer olá")
    print("2 - Mostrar data atual")
    print("3 - Sair")
    
    opcao = input("Escolha uma opção: ")
    
    if opcao == "1":
        print("Olá! Seja bem-vindo!")
    elif opcao == "2":
        from datetime import datetime
        print(f"Data atual: {datetime.now().strftime('%d/%m/%Y')}")
    elif opcao == "3":
        print("Saindo... Até logo!")
        break
    else:
        print("Opção inválida. Tente novamente.")

