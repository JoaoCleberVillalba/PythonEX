# Exercício 4: Leia 5 números e calcule a média

soma = 0
for i in range(1, 6):
    numero = float(input(f"Digite o {i}º número: "))
    soma += numero

media = soma / 5
print(f"A média dos 5 números é: {media}")

