# Exercício 2: Imprima números pares de 1 a 20

print("Números pares de 1 a 20:")
for i in range(1, 21):
    if i % 2 == 0:
        print(i)

