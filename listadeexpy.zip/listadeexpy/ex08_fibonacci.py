# Exercício 8: Sequência de Fibonacci (n termos)

n = int(input("Quantos termos da sequência de Fibonacci você quer ver? "))

termo1 = 0
termo2 = 1

print("Sequência de Fibonacci:")
for _ in range(n):
    print(termo1, end=" ")
    proximo = termo1 + termo2
    termo1 = termo2
    termo2 = proximo

print()  # Quebra de linha no final

