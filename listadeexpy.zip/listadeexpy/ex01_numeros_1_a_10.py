# Exercício 1: Imprima números de 1 a 10

print("Números de 1 a 10:")
for i in range(1, 11):
    print(i)

