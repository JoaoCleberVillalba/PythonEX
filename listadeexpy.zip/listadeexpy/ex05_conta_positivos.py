# Exercício 5: Conte quantos números positivos foram digitados

quantidade_positivos = 0

while True:
    numero = float(input("Digite um número (ou 0 para sair): "))
    if numero == 0:
        break
    if numero > 0:
        quantidade_positivos += 1

print(f"Quantidade de números positivos digitados: {quantidade_positivos}")

