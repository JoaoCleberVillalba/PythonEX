idade = int(input('Digite sua idade: '))

if idade < 18:
    print('Criança')
elif idade < 60:
    print('Adulto')
else:
    print('Idoso')
