tentativas = 3

while tentativas > 0:
    usuario = input('Usuário: ')
    senha = input('Senha: ')
    
    if usuario == 'admin' and senha == '1234':
        print('Login realizado com sucesso!')
        break
    else:
        print('Usuário ou senha inválidos!')
        tentativas -= 1
        if tentativas > 0:
            print(f'Tentativas restantes: {tentativas}')

if tentativas == 0:
    print('Conta bloqueada!')
