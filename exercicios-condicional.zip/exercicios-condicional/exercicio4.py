print('Digite três números:')
num1 = float(input('Primeiro número: '))
num2 = float(input('Segundo número: '))
num3 = float(input('Terceiro número: '))

maior = max(num1, num2, num3)
print(f'O maior número é {maior}')
