print('Digite dois números:')
num1 = float(input('Primeiro número: '))
num2 = float(input('Segundo número: '))

if num1 > num2:
    print(f'O maior número é {num1}')
elif num2 > num1:
    print(f'O maior número é {num2}')
else:
    print('Os números são iguais')
