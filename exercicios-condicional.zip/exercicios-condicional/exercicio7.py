salario = float(input('Digite o salário: '))

if salario > 5000:
    desconto = salario * 0.10
else:
    desconto = salario * 0.05

novo_salario = salario - desconto
print(f'Desconto aplicado: R$ {desconto:.2f}')
print(f'Novo salário: R$ {novo_salario:.2f}')
