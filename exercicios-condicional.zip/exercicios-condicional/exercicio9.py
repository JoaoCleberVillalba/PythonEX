print('=== CALCULADORA ===')
num1 = float(input('Primeiro número: '))
num2 = float(input('Segundo número: '))
operacao = input('Escolha a operação (+, -, *, /): ')

if operacao == '+':
    resultado = num1 + num2
elif operacao == '-':
    resultado = num1 - num2
elif operacao == '*':
    resultado = num1 * num2
elif operacao == '/':
    if num2 != 0:
        resultado = num1 / num2
    else:
        print('Erro: Divisão por zero!')
        exit()
else:
    print('Operação inválida!')
    exit()

print(f'Resultado: {resultado}')
