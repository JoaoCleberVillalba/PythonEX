nota1 = float(input('Digite a primeira nota (0-10): '))
nota2 = float(input('Digite a segunda nota (0-10): '))

media = (nota1 + nota2) / 2

if media >= 7:
    print('Aprovado')
elif media >= 5:
    print('Recuperação')
else:
    print('Reprovado')

print(f'Média: {media:.2f}')
