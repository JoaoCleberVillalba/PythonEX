nome = input("Digite seu nome completo: ")
idade = int(input("Digite sua idade: "))
cidade = input("Digite sua cidade: ")
print(f"Cadastro:\nNome: {nome}\nIdade: {idade}\nCidade: {cidade}")
