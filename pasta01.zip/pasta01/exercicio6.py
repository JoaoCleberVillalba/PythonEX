celsius = float(input("Digite a temperatura em °C: "))
fahrenheit = (celsius * 9 / 5) + 32
print(f"{celsius}°C é {fahrenheit:.1f}°F")
