salario = float(input("Digite o salário atual (R$): "))
novo_salario = salario * 1.10
print(f"Salário com aumento de 10%: R$ {novo_salario:.2f}")
