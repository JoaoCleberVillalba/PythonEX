a = float(input("Digite o primeiro número: "))
b = float(input("Digite o segundo número: "))
print(f"Resultados:\nSoma: {a+b}\nSubtração: {a-b}\nMultiplicação: {a*b}\nDivisão: {a/b}\nDivisão Inteira: {a//b}\nResto: {a%b}")
