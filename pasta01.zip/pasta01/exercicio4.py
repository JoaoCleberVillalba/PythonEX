from datetime import datetime
nascimento = int(input("Digite seu ano de nascimento: "))
hoje = datetime.now().year
idade = hoje - nascimento
print(f"Sua idade é {idade} anos.")
