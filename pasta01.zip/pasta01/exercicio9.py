valor_hora = float(input("Valor por hora (R$): "))
horas = float(input("Horas no mês: "))
salario_bruto = valor_hora * horas
desconto = salario_bruto * 0.11
liquido = salario_bruto - desconto
print(f"Salário Bruto: R$ {salario_bruto:.2f}\nINSS (11%): R$ {desconto:.2f}\nSalário Líquido: R$ {liquido:.2f}")
